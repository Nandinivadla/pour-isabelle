# Un petit monde pour Isabelle 🌷

Un site de douceur et de petites surprises, en français, conçu pour les téléphones et les ordinateurs.

## Aperçu local
1. Décompressez le dossier.
2. Ouvrez `index.html` dans Chrome, Safari ou Firefox.
3. Appuyez sur **Musique douce** si vous souhaitez entendre les petites notes générées par le navigateur. La musique ne démarre jamais toute seule.

## Publier sur GitHub Pages
1. Créez un nouveau dépôt GitHub public, par exemple `pour-isabelle`.
2. Ajoutez le fichier `index.html` à la racine du dépôt.
3. Ouvrez **Settings → Pages**.
4. Dans **Build and deployment**, choisissez **Deploy from a branch**.
5. Choisissez la branche `main` et le dossier `/ (root)`, puis cliquez sur **Save**.
6. Attendez la fin du déploiement. GitHub affichera l'adresse du site dans la section Pages.
7. Ouvrez le lien sur votre téléphone pour le tester, puis envoyez-le à Isabelle.

## Personnaliser
- Le nom et les textes sont directement dans `index.html`.
- Les messages tendres et humoristiques sont dans les tableaux JavaScript `messages.tendre` et `messages.drôle`.
- La musique est synthétisée localement avec Web Audio API : aucun fichier audio externe n'est requis.
- Le site ne collecte aucune donnée et n'a besoin d'aucune bibliothèque externe.

Conseil : créez un dépôt séparé pour ce cadeau, afin de ne pas remplacer votre portfolio existant.
